# sar_guia — Guía de interpretación multisensor (S1 · ALOS-2 · S2)

Replica el formato de la *CEOS Layman's SAR Interpretation Guide v3.0* para tu AOI:
panel 3×4 (S1: VV, VH, VV/VH, RGB · ALOS-2: HH, HV, HH/HV, RGB · S2: NIR, Green, Red, RGB),
con las tres fechas dentro de ±15 días, y salidas en **PNG, GeoTIFF y PDF**.

## Instalación y uso
```bash
pip install -r requirements.txt
earthengine authenticate            # una vez; edita GEE_PROJECT en config.py
python main.py                      # módulos 1 → 2 → 3
python main.py --modulo 3           # regenerar solo panel/PDF
python main.py --slc                # + fase (S1 SLC, requiere SNAP y cuenta Earthdata)
python -m pruebas.prueba_offline    # prueba sin internet (escena sintética)
```

## Arquitectura (3 módulos independientes)
```
config.py                 ← ÚNICO lugar con parámetros (AOI, fechas, ventanas, rutas)
nucleo/
  utilidades.py           ← AOI 3857→4326, manifiesto JSON, logging
  io_raster.py            ← ÚNICA E/S raster (rasterio). Cambiar backend = tocar solo aquí
modulo1_adquisicion/      FASE 1: ¿qué datos y cuándo?
  gee_busqueda.py         ← emparejamiento temporal (ALOS ancla) + nubes en AOI
  gee_descarga.py         ← descarga GeoTIFF crudo (valores físicos) + metadatos
  slc_asf.py              ← (opcional) S1 SLC complejo + SNAP (snap_graphs/*.xml)
modulo2_procesamiento/    FASE 2: física y matemática
  radiometria.py          ← DN→γ0, σ0→γ0, dB, estadísticas (promedio en lineal)
  speckle.py              ← Lee + estimación ENL   (registro FILTROS para ampliar)
  polarimetria.py         ← I/Q, amplitud, fase, C2, coherencia, H/α dual
  composiciones.py        ← RGB SAR y óptico
  procesar.py             ← orquestador
modulo3_productos/        FASE 3: productos
  panel.py · textos.py · reporte_pdf.py · generar.py
salidas/01_raw · 02_procesado · 03_productos · manifiesto.json
```
**Contrato entre módulos = `salidas/manifiesto.json`.** Cada módulo lee lo que necesita y
escribe solo su clave (`adquisicion`, `procesamiento`, `slc`, `productos`). Por eso puedes
reescribir un módulo sin romper los demás, y re-ejecutar el 2 o el 3 sin volver a descargar.

## Decisiones científicas clave
| Tema | Decisión |
|---|---|
| S1 | `S1_GRD_FLOAT` (σ0 lineal) → γ0 = σ0/cosθ (θ elipsoidal; **no es RTC completa**) → Lee 5×5, ENL 4.4 |
| ALOS-2 | ScanSAR L2.2 (multi-fecha); respaldo: mosaico anual. γ0 = DN²·10^(−8.3); remuestreo 25→10 m en potencia |
| S2 | L2A armonizada, ρ = DN/10000, nubes SCL 3/8/9/10 |
| Estadísticas | media en lineal → dB; desviación en dB; cociente = cociente de medias |
| Fase | solo en SLC. GRD y mosaicos ALOS no tienen fase. ALOS-2 SLC no es de libre acceso |

## Puntos a verificar en tu primera ejecución real
1. Valores de la banda `MSK` de ALOS ScanSAR en el catálogo GEE (el código solo los reporta).
2. Si hay ScanSAR sobre el AOI en el periodo; si no, se usa el mosaico anual (fecha por píxel).
3. En `slc_asf.py`, la autodetección de sub-swath (revisar en SNAP si el AOI cae entre dos).

## Hoja de ruta sugerida (nuevos submódulos)
- M1: backend alternativo Planetary Computer / ASF HyP3 (S1 RTC real); NISAR (L-band, libre).
- M2: Refined Lee / filtro multitemporal; RTC propia con DEM; series temporales (reduce "ruido"
  temporal, sec. 4.1 de la guía); índices RVI dual, NDVI/NDWI; muestreo de polígonos por clase.
- M3: panel por clase (varios polígonos) como la guía; mapa de ubicación; exportar COG.
- Transversal: tests unitarios en `pruebas/`, caché de consultas GEE, CLI por submódulo.

## CONTEXTO PARA RETOMAR (pégalo en una nueva conversación)
> Proyecto `sar_guia` (Python). 3 módulos desacoplados por `salidas/manifiesto.json`:
> M1 adquisición (GEE: S1_GRD_FLOAT, ALOS-2 ScanSAR L2.2, S2_SR_HARMONIZED; ventana ±15 d;
> opcional SLC ASF+SNAP), M2 procesamiento (radiometria, speckle, polarimetria, composiciones),
> M3 productos (panel 3×4, PDF ReportLab con DejaVu). Parámetros solo en `config.py`;
> E/S raster solo en `nucleo/io_raster.py`. AOI EPSG:3857 bbox (-8163798.97, 419908.38,
> -8158657.89, 425023.37) ≈ lon −73.34/−73.29, lat 3.77/3.82, trabajo en EPSG:32618 a 10 m.
> Quiero ahora: <tu siguiente mejora>.
