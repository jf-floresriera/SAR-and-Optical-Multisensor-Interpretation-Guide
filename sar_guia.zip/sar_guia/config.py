"""Configuración ÚNICA del proyecto. Ningún módulo define constantes propias:
todo parámetro ajustable vive aquí (así se cambia algo sin tocar la lógica)."""
from pathlib import Path

# ---------------- Área de interés (tal como viene de QGIS) ----------------
AOI_CRS = "EPSG:3857"
AOI_BBOX = (-8163798.9687834633514285, 419908.3805525006609969,
            -8158657.8866232894361019, 425023.3658489169902168)
CRS_TRABAJO = "EPSG:32618"      # UTM 18N (lon ≈ -73.3°, hemisferio norte)
NOMBRE_AOI = "AOI Meta-Colombia (~5.1 x 5.1 km)"

# ---------------- Búsqueda temporal ----------------
FECHA_INICIO, FECHA_FIN = "2019-01-01", "2025-12-31"
VENTANA_DIAS = 15                # diferencia máxima entre las 3 fechas
S2_NUBES_ESCENA_MAX = 60         # filtro grueso (metadato de la escena, %)
S2_NUBES_AOI_MAX = 10            # filtro fino (SCL dentro del AOI, %)
MAX_EVAL_NUBES = 40              # límite de consultas a GEE

# ---------------- Resoluciones de descarga (m) ----------------
RES = {"s1": 10, "s2": 10, "alos": 25}   # ALOS se remuestrea a 10 m en módulo 2

# ---------------- Procesamiento ----------------
SPECKLE = {"s1": {"metodo": "lee", "ventana": 5, "enl": 4.4},   # ENL IW-GRDH (ESA)
           "alos": None}                                        # mosaico ya multi-look
PERCENTILES_VIS = (2, 98)
K_ALOS_DB = -83.0                # factor de calibración JAXA (guía CEOS, sec. 3.1.2.3)

# ---------------- Google Earth Engine ----------------
GEE_PROJECT = "TU-PROYECTO-GEE"
COL_S1 = "COPERNICUS/S1_GRD_FLOAT"                    # sigma0 lineal
COL_S2 = "COPERNICUS/S2_SR_HARMONIZED"                # reflectancia BOA x10000
COL_ALOS = "JAXA/ALOS/PALSAR-2/Level2_2/ScanSAR"      # multi-fecha (permite emparejar)
COL_ALOS_ANUAL = "JAXA/ALOS/PALSAR/YEARLY/SAR_EPOCH"  # respaldo (mosaico anual)
ALOS2_LANZAMIENTO = "2014-05-24"

# ---------------- SLC / fase (opcional) ----------------
SLC = {"activar": False, "snap_gpt": "gpt", "subswath": None,   # None = autodetectar
       "ventana_c2": 7, "earthdata_user": "", "earthdata_pass": ""}

# ---------------- Rutas (contrato entre módulos) ----------------
BASE = Path(__file__).parent / "salidas"
RAW, PROC, PROD = BASE / "01_raw", BASE / "02_procesado", BASE / "03_productos"
MANIFIESTO = BASE / "manifiesto.json"

# ---------------- Constantes físicas de sensores ----------------
C = 299_792_458.0
SENSORES = {
    "s1":   {"nombre": "Sentinel-1 C-SAR", "f_hz": 5.405e9, "banda": "C",
             "pols": ["VV", "VH"], "agencia": "ESA / Copernicus"},
    "alos": {"nombre": "ALOS-2 PALSAR-2", "f_hz": 1.2365e9, "banda": "L",
             "pols": ["HH", "HV"], "agencia": "JAXA"},
    "s2":   {"nombre": "Sentinel-2 MSI", "banda": "Óptico",
             "bandas_nm": {"B2": 492.4, "B3": 559.8, "B4": 664.6, "B8": 832.8},
             "agencia": "ESA / Copernicus"},
}
