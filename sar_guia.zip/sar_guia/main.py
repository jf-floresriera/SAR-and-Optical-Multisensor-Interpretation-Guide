"""Punto de entrada.  Ejemplos:
    python main.py                  # los 3 módulos
    python main.py --modulo 2       # solo reprocesar (sin volver a descargar)
    python main.py --modulo 3       # solo regenerar panel/PDF
    python main.py --slc            # añade fase (Sentinel-1 SLC + SNAP)
"""
import argparse
import config as cfg

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--modulo", choices=["1", "2", "3", "todos"], default="todos")
    ap.add_argument("--slc", action="store_true")
    a = ap.parse_args()
    if a.modulo in ("1", "todos"):
        from modulo1_adquisicion import gee_descarga
        sel = gee_descarga.ejecutar()
        if a.slc or cfg.SLC["activar"]:
            from modulo1_adquisicion import slc_asf
            slc_asf.ejecutar(sel["s1"]["fecha"])
    if a.modulo in ("2", "todos"):
        from modulo2_procesamiento import procesar
        procesar.ejecutar()
    if a.modulo in ("3", "todos"):
        from modulo3_productos import generar
        generar.ejecutar()

if __name__ == "__main__":
    main()
