"""MÓDULO 1a – Búsqueda y emparejamiento temporal (S1, ALOS-2, S2) en Google Earth Engine.

Idea clave: ALOS-2 es el sensor con MENOS fechas -> se usa como ancla y se buscan
S1 y S2 a ±VENTANA_DIAS. Solo se consultan nubes (costoso) para candidatos ya
válidos temporalmente, ordenados por cercanía -> pocas llamadas a GEE."""
from collections import defaultdict
from datetime import datetime, timedelta, timezone
import ee
import config as cfg
from nucleo.utilidades import aoi_lonlat, log

L = log("M1-busqueda")

def iniciar():
    try:
        ee.Initialize(project=cfg.GEE_PROJECT)
    except Exception:
        ee.Authenticate()
        ee.Initialize(project=cfg.GEE_PROJECT)

def geometria():
    return ee.Geometry.Polygon([aoi_lonlat()], None, False)

# ---------------------------------------------------------------- colecciones
def col_s1(aoi):
    return (ee.ImageCollection(cfg.COL_S1).filterBounds(aoi)
            .filterDate(cfg.FECHA_INICIO, cfg.FECHA_FIN)
            .filter(ee.Filter.eq("instrumentMode", "IW"))
            .filter(ee.Filter.listContains("transmitterReceiverPolarisation", "VV"))
            .filter(ee.Filter.listContains("transmitterReceiverPolarisation", "VH")))

def col_s2(aoi):
    return (ee.ImageCollection(cfg.COL_S2).filterBounds(aoi)
            .filterDate(cfg.FECHA_INICIO, cfg.FECHA_FIN)
            .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", cfg.S2_NUBES_ESCENA_MAX)))

def col_alos(aoi):
    return (ee.ImageCollection(cfg.COL_ALOS).filterBounds(aoi)
            .filterDate(cfg.FECHA_INICIO, cfg.FECHA_FIN)
            .filter(ee.Filter.listContains("system:band_names", "HV")))

def fechas_por_dia(col, clave_extra=None):
    """{date: [ids]} agrupando escenas del mismo día (mosaico de slices/tiles).
    Para S1 se agrupa también por órbita relativa para no mezclar geometrías."""
    props = ["system:index", "system:time_start"] + ([clave_extra] if clave_extra else [])
    filas = col.reduceColumns(ee.Reducer.toList(len(props)), props).get("list").getInfo()
    grupos = defaultdict(list)
    for f in filas:
        d = datetime.fromtimestamp(f[1] / 1000, tz=timezone.utc).date()
        grupos[(d, f[2] if clave_extra else None)].append(f[0])
    return grupos

# ---------------------------------------------------------------- nubes
_cache_nubes = {}
def nubes_aoi(ids, aoi):
    """% de píxeles nube/sombra/cirro (SCL 3,8,9,10) dentro del AOI."""
    k = tuple(sorted(ids))
    if k not in _cache_nubes:
        img = ee.ImageCollection([ee.Image(f"{cfg.COL_S2}/{i}") for i in ids]).mosaic()
        scl = img.select("SCL")
        nube = scl.eq(3).Or(scl.eq(8)).Or(scl.eq(9)).Or(scl.eq(10)).rename("n")
        v = nube.reduceRegion(ee.Reducer.mean(), aoi, 20, maxPixels=1e9).get("n").getInfo()
        _cache_nubes[k] = 100.0 if v is None else 100.0 * v
    return _cache_nubes[k]

# ---------------------------------------------------------------- respaldo ALOS anual
def fecha_mosaico_anual(aoi, anio):
    """Fecha mediana de observación del mosaico anual (banda de fecha = días desde lanzamiento)."""
    img = (ee.ImageCollection(cfg.COL_ALOS_ANUAL)
           .filterDate(f"{anio}-01-01", f"{anio}-12-31").first())
    bandas = img.bandNames().getInfo()
    b = next((x for x in bandas if x.lower() in ("date", "epoch", "obs_date")), None)
    if b is None:
        return img, datetime(anio, 7, 1).date()
    dias = img.select(b).reduceRegion(ee.Reducer.median(), aoi, 25).get(b).getInfo()
    base = datetime.fromisoformat(cfg.ALOS2_LANZAMIENTO).date()
    return img, base + timedelta(days=int(dias))

# ---------------------------------------------------------------- emparejamiento
def emparejar(aoi):
    g_alos = fechas_por_dia(col_alos(aoi))
    g_s1 = fechas_por_dia(col_s1(aoi), "relativeOrbitNumber_start")
    g_s2 = fechas_por_dia(col_s2(aoi))
    L.info(f"Fechas: ALOS={len(g_alos)}  S1={len(g_s1)}  S2={len(g_s2)}")

    anclas = [(k[0], ids, "scansar") for k, ids in g_alos.items()]
    if not anclas:   # respaldo: mosaicos anuales
        L.warning("Sin ALOS-2 ScanSAR en el AOI: uso mosaico anual (fecha por píxel).")
        for anio in range(int(cfg.FECHA_INICIO[:4]), int(cfg.FECHA_FIN[:4]) + 1):
            try:
                _, d = fecha_mosaico_anual(aoi, anio)
                anclas.append((d, [f"anual_{anio}"], "anual"))
            except Exception:
                pass

    w = cfg.VENTANA_DIAS
    cands = []
    for da, ids_a, tipo in anclas:
        for (d1, orb), ids1 in g_s1.items():
            if abs((d1 - da).days) > w:
                continue
            for (d2, _), ids2 in g_s2.items():
                fechas = (da, d1, d2)
                span = (max(fechas) - min(fechas)).days
                if span <= w:
                    cands.append((span, da, ids_a, tipo, d1, orb, ids1, d2, ids2))
    cands.sort(key=lambda c: c[0])
    L.info(f"{len(cands)} tripletas temporales válidas; evaluando nubes…")

    for c in cands[: cfg.MAX_EVAL_NUBES]:
        n = nubes_aoi(c[8], aoi)
        if n <= cfg.S2_NUBES_AOI_MAX:
            span, da, ids_a, tipo, d1, orb, ids1, d2, ids2 = c
            L.info(f"Elegido: ALOS {da} | S1 {d1} (órb {orb}) | S2 {d2} ({n:.1f}% nubes) span={span} d")
            return {"alos": {"fecha": str(da), "ids": ids_a, "tipo": tipo},
                    "s1": {"fecha": str(d1), "ids": ids1, "orbita_rel": orb},
                    "s2": {"fecha": str(d2), "ids": ids2, "nubes_aoi_pct": round(n, 2)},
                    "span_dias": span}
    raise RuntimeError("Ninguna tripleta cumple ventana + nubes. Amplía fechas, "
                       "VENTANA_DIAS o S2_NUBES_AOI_MAX en config.py")
