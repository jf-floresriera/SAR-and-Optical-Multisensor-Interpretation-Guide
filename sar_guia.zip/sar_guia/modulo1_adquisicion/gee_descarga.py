"""MÓDULO 1b – Construcción de imágenes, descarga GeoTIFF y extracción de metadatos.

Se descargan valores FÍSICOS SIN transformar (sigma0 lineal, DN ALOS, reflectancia x1e4)
para que toda la radiometría sea explícita y auditable en el módulo 2."""
import requests
import ee
import config as cfg
from nucleo.utilidades import log, actualizar_manifiesto, aoi_lonlat
from . import gee_busqueda as gb

L = log("M1-descarga")

def _img_s1(ids):
    return ee.ImageCollection([ee.Image(f"{cfg.COL_S1}/{i}") for i in ids]) \
             .mosaic().select(["VV", "VH", "angle"]).toFloat()

def _img_s2(ids):
    return ee.ImageCollection([ee.Image(f"{cfg.COL_S2}/{i}") for i in ids]) \
             .mosaic().select(["B2", "B3", "B4", "B8", "SCL"]).toUint16()

def _img_alos(sel, aoi):
    if sel["tipo"] == "scansar":
        col = ee.ImageCollection([ee.Image(f"{cfg.COL_ALOS}/{i}") for i in sel["ids"]])
    else:
        anio = sel["ids"][0].split("_")[1]
        col = ee.ImageCollection(cfg.COL_ALOS_ANUAL).filterDate(f"{anio}-01-01", f"{anio}-12-31")
    return col.mosaic().select(["HH", "HV", "LIN", "MSK"]).toUint16()

def descargar(img, ruta, aoi, escala):
    url = img.getDownloadURL({"region": aoi, "scale": escala,
                              "crs": cfg.CRS_TRABAJO, "format": "GEO_TIFF"})
    r = requests.get(url, timeout=600)
    r.raise_for_status()
    ruta.write_bytes(r.content)
    L.info(f"Descargado {ruta.name} ({len(r.content)/1e6:.1f} MB)")

def _metadatos(coleccion, ids):
    """Todas las propiedades escalares de cada escena (auditoría completa)."""
    out = []
    for i in ids:
        if i.startswith("anual_"):
            out.append({"producto": "mosaico anual ALOS-2", "anio": i.split("_")[1]})
            continue
        d = ee.Image(f"{coleccion}/{i}").toDictionary().getInfo()
        out.append({k: v for k, v in d.items() if not isinstance(v, (list, dict))
                    or len(str(v)) < 300} | {"id": i})
    return out

def ejecutar():
    gb.iniciar()
    aoi = gb.geometria()
    sel = gb.emparejar(aoi)
    cfg.RAW.mkdir(parents=True, exist_ok=True)

    rutas = {s: cfg.RAW / f"{s}_{sel[s]['fecha']}.tif" for s in ("s1", "s2", "alos")}
    descargar(_img_s1(sel["s1"]["ids"]), rutas["s1"], aoi, cfg.RES["s1"])
    descargar(_img_s2(sel["s2"]["ids"]), rutas["s2"], aoi, cfg.RES["s2"])
    descargar(_img_alos(sel["alos"], aoi), rutas["alos"], aoi, cfg.RES["alos"])

    sel["s1"] |= {"archivo": str(rutas["s1"]), "bandas": ["VV", "VH", "angle"],
                  "producto": "IW GRDH sigma0 lineal (GEE: ruido térmico, calibración, ortorrectificación)",
                  "metadatos": _metadatos(cfg.COL_S1, sel["s1"]["ids"])}
    sel["s2"] |= {"archivo": str(rutas["s2"]), "bandas": ["B2", "B3", "B4", "B8", "SCL"],
                  "producto": "L2A reflectancia de superficie (armonizada)",
                  "metadatos": _metadatos(cfg.COL_S2, sel["s2"]["ids"])}
    sel["alos"] |= {"archivo": str(rutas["alos"]), "bandas": ["HH", "HV", "LIN", "MSK"],
                    "producto": "L2.2 ScanSAR gamma0 (DN amplitud)" if sel["alos"]["tipo"] == "scansar"
                                else "Mosaico anual gamma0 (DN amplitud)",
                    "metadatos": _metadatos(cfg.COL_ALOS, sel["alos"]["ids"])}
    actualizar_manifiesto(aoi={"crs_origen": cfg.AOI_CRS, "bbox": cfg.AOI_BBOX,
                               "lonlat": aoi_lonlat(), "crs_trabajo": cfg.CRS_TRABAJO,
                               "nombre": cfg.NOMBRE_AOI},
                          adquisicion=sel)
    return sel
