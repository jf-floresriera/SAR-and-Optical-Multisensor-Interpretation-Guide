"""MÓDULO 1c (OPCIONAL) – Datos COMPLEJOS (fase) de Sentinel-1 SLC vía ASF + SNAP.

Por qué es opcional: los productos GRD (GEE) y los mosaicos ALOS YA NO contienen fase
(se detectó |s|² y se promedió). La fase solo existe en SLC:
  * Sentinel-1 SLC: libre (ASF, requiere cuenta NASA Earthdata).
  * ALOS-2 SLC (L1.1): NO es de libre acceso (JAXA, licencia/propuesta de investigación).
    Alternativa libre en banda L: ALOS-1 PALSAR L1.1 (2006-2011) en ASF, sin coincidencia temporal.
"""
import subprocess
from collections import Counter
from pathlib import Path
import config as cfg
from nucleo.utilidades import log, aoi_lonlat, actualizar_manifiesto

L = log("M1-SLC")

def _wkt():
    return "POLYGON((" + ",".join(f"{x} {y}" for x, y in aoi_lonlat()) + "))"

def buscar_y_descargar(fecha_s1):
    import asf_search as asf
    from datetime import date, timedelta
    d = date.fromisoformat(fecha_s1)
    kw = dict(platform=asf.PLATFORM.SENTINEL1, beamMode=asf.BEAMMODE.IW,
              intersectsWith=_wkt(), start=str(d), end=str(d + timedelta(days=1)))
    slc = asf.geo_search(processingLevel=asf.PRODUCT_TYPE.SLC, **kw)
    if not slc:
        raise RuntimeError(f"No hay SLC para {fecha_s1}")
    # Autodetección de sub-swath: los productos BURST traen la sub-franja en metadatos
    sub = cfg.SLC["subswath"]
    if sub is None:
        bursts = asf.geo_search(processingLevel=asf.PRODUCT_TYPE.BURST, **kw)
        cuenta = Counter(b.properties.get("burst", {}).get("subswath") for b in bursts)
        sub = cuenta.most_common(1)[0][0] if cuenta else "IW2"
        if len(cuenta) > 1:
            L.warning(f"El AOI cruza sub-franjas {dict(cuenta)}; uso {sub}")
    ses = asf.ASFSession().auth_with_creds(cfg.SLC["earthdata_user"], cfg.SLC["earthdata_pass"])
    destino = cfg.RAW / "slc"
    destino.mkdir(parents=True, exist_ok=True)
    slc[0].download(path=str(destino), session=ses)
    return destino / slc[0].properties["fileName"], sub, slc[0].properties

def procesar_snap(zip_slc, subswath):
    graph = Path(__file__).parents[1] / "snap_graphs" / "s1_slc_c2.xml"
    base = cfg.RAW / "slc" / Path(zip_slc).stem
    cmd = [cfg.SLC["snap_gpt"], str(graph), f"-Pentrada={zip_slc}", f"-Psubswath={subswath}",
           f"-Pwkt={_wkt()}", f"-Psalida_complejo={base}_cplx", f"-Psalida_c2={base}_C2"]
    L.info("Ejecutando SNAP gpt (puede tardar 10-40 min)…")
    subprocess.run(cmd, check=True)
    return f"{base}_cplx.data", f"{base}_C2.tif"

def ejecutar(fecha_s1):
    z, sub, props = buscar_y_descargar(fecha_s1)
    cplx, c2 = procesar_snap(z, sub)
    actualizar_manifiesto(slc={"archivo_zip": str(z), "subswath": sub, "dir_complejo": cplx,
                               "c2_geocodificado": c2,
                               "metadatos": {k: v for k, v in props.items() if not isinstance(v, dict)}})
