"""Composiciones de color (guía CEOS sec. 4.1): SAR [co, cross, co/cross]; óptico RGB real."""
import numpy as np
import config as cfg

def estirar(x, p=cfg.PERCENTILES_VIS):
    lo, hi = np.nanpercentile(x, p)
    return np.clip((x - lo) / max(hi - lo, 1e-9), 0, 1)

def rgb_sar(co_db, cross_db):
    """R=co, G=cross, B=co/cross. El cociente lineal equivale a la RESTA en dB."""
    return np.dstack([estirar(co_db), estirar(cross_db), estirar(co_db - cross_db)])

def rgb_optico(rojo, verde, azul, gamma=1.0):
    return np.dstack([estirar(b) ** (1 / gamma) for b in (rojo, verde, azul)])

def a_uint8(rgb):
    return (np.nan_to_num(rgb) * 254 + 1).astype("uint8").transpose(2, 0, 1)  # 0 = nodata
