"""Datos COMPLEJOS y polarimetría dual (VV/VH) – usa la parte real e IMAGINARIA.

  s = I + jQ          amplitud A = |s|,  intensidad P = |s|²,  fase φ = atan2(Q, I)
  C2 = < [s_vv; s_vh] [s_vv; s_vh]^H >  (promedio espacial, matriz hermítica 2x2)
       C11=<|s_vv|²>, C22=<|s_vh|²>, C12=<s_vv·s_vh*>
  Coherencia interpolar  ρ = |C12| / sqrt(C11·C22)  ∈ [0,1]
  Descomposición H/α dual (Cloude 2007): autovalores λ1≥λ2, p_i = λ_i/Σλ,
  H = −Σ p_i log2 p_i ,  α_i = arccos|e_i[0]| ,  ᾱ = Σ p_i α_i
"""
import numpy as np
from scipy.ndimage import uniform_filter

def complejo(i, q):
    return np.asarray(i, "float64") + 1j * np.asarray(q, "float64")

def amplitud(s):  return np.abs(s)
def intensidad(s): return np.abs(s) ** 2
def fase(s):      return np.angle(s)            # radianes (−π, π]

def _boxcar_c(z, w):
    return uniform_filter(z.real, w) + 1j * uniform_filter(z.imag, w)

def matriz_c2(s_vv, s_vh, ventana=7):
    c11 = uniform_filter(intensidad(s_vv), ventana)
    c22 = uniform_filter(intensidad(s_vh), ventana)
    c12 = _boxcar_c(s_vv * np.conj(s_vh), ventana)
    return c11, c22, c12

def coherencia(c11, c22, c12):
    return np.abs(c12) / np.sqrt(np.maximum(c11 * c22, 1e-20))

def diferencia_fase(c12):
    return np.angle(c12)

def h_alpha(c11, c22, c12):
    """Forma cerrada para matrices hermíticas 2x2 (vectorizada, sin eig por píxel)."""
    tr = c11 + c22
    d = np.sqrt(((c11 - c22) / 2) ** 2 + np.abs(c12) ** 2)
    lam = np.stack([tr / 2 + d, np.maximum(tr / 2 - d, 0)])
    a12 = np.abs(c12) + 1e-20
    # autovector (C12, λ−C11): |e0| = |C12| / sqrt(|C12|² + (λ−C11)²)
    e0 = a12 / np.sqrt(a12 ** 2 + (lam - c11) ** 2)
    alfa_i = np.degrees(np.arccos(np.clip(e0, 0, 1)))
    p = lam / np.maximum(tr, 1e-20)
    H = -np.sum(np.where(p > 0, p * np.log2(np.maximum(p, 1e-20)), 0), axis=0)
    alfa = np.sum(p * alfa_i, axis=0)
    return H, alfa, lam

def leer_complejo_snap(dir_data):
    """Lee i_VV, q_VV, i_VH, q_VH de un producto BEAM-DIMAP (.data con .img ENVI)."""
    import rasterio
    from pathlib import Path
    d = Path(dir_data)
    def b(n):
        f = next(d.glob(f"{n}*.img"))
        with rasterio.open(f) as ds:
            return ds.read(1)
    return complejo(b("i_VV"), b("q_VV")), complejo(b("i_VH"), b("q_VH"))
