"""MÓDULO 2 – Orquestador: raw (módulo 1) -> capas físicas alineadas + estadísticas."""
import numpy as np
import config as cfg
from nucleo import io_raster as io
from nucleo.utilidades import log, leer_manifiesto, actualizar_manifiesto
from . import radiometria as rad, speckle as spk, composiciones as comp, polarimetria as pol

L = log("M2")

def _filtrar(lin, sensor):
    p = cfg.SPECKLE.get(sensor)
    return lin if not p else spk.FILTROS[p["metodo"]](lin, p["ventana"], p["enl"])

def procesar_s2(adq):
    arr, perfil, _ = io.leer(adq["s2"]["archivo"])
    b2, b3, b4, b8, scl = arr
    nube = np.isin(scl, [3, 8, 9, 10])
    refl = {k: rad.s2_reflectancia(v) for k, v in dict(B2=b2, B3=b3, B4=b4, B8=b8).items()}
    for v in refl.values():
        v[nube] = np.nan
    return perfil, refl

def procesar_s1(adq, perfil):
    vv, vh, ang = io.alinear(adq["s1"]["archivo"], perfil)
    g = {p: _filtrar(rad.sigma_a_gamma(x, ang), "s1") for p, x in (("VV", vv), ("VH", vh))}
    return g, {"angulo_inc_media": float(np.nanmean(ang)),
               "angulo_inc_min": float(np.nanmin(ang)), "angulo_inc_max": float(np.nanmax(ang)),
               "enl_estimado_VV_crudo": spk.enl_estimado(vv)}

def procesar_alos(adq, perfil):
    """DN -> potencia lineal en la grilla NATIVA (25 m) y luego remuestreo bilineal
    a 10 m sobre potencia (promediar DN o dB sesgaría el resultado)."""
    arr, p_src, _ = io.leer(adq["alos"]["archivo"])
    hh_dn, hv_dn, lin, msk = arr
    pot = np.stack([rad.alos_dn_a_lineal(hh_dn), rad.alos_dn_a_lineal(hv_dn)])
    hh, hv = io.reproyectar(pot, p_src, perfil, "bilinear")
    lin_a, msk_a = io.reproyectar(np.stack([lin, msk]), p_src, perfil, "nearest")
    g = {"HH": _filtrar(hh, "alos"), "HV": _filtrar(hv, "alos")}
    vals, cnt = np.unique(msk_a[np.isfinite(msk_a)], return_counts=True)
    return g, {"angulo_inc_local_media": float(np.nanmean(np.where(lin_a > 0, lin_a, np.nan))),
               "mascara_valores": {str(int(v)): int(c) for v, c in zip(vals, cnt)}}

def ejecutar():
    man = leer_manifiesto()
    adq = man["adquisicion"]
    cfg.PROC.mkdir(parents=True, exist_ok=True)
    perfil, refl = procesar_s2(adq)
    s1, meta_s1 = procesar_s1(adq, perfil)
    al, meta_al = procesar_alos(adq, perfil)
    capas, stats = {}, {}

    for sensor, g, co, cx in (("s1", s1, "VV", "VH"), ("alos", al, "HH", "HV")):
        co_db, cx_db = rad.a_db(g[co]), rad.a_db(g[cx])
        ratio_lin = g[co] / g[cx]
        io.escribir(cfg.PROC / f"{sensor}_gamma0_db.tif", np.stack([co_db, cx_db, co_db - cx_db]),
                    perfil, [f"{co}_dB", f"{cx}_dB", f"{co}/{cx}_dB"])
        io.escribir(cfg.PROC / f"{sensor}_gamma0_lineal.tif", np.stack([g[co], g[cx]]),
                    perfil, [f"{co}_lin", f"{cx}_lin"])
        rgb = comp.rgb_sar(co_db, cx_db)
        io.escribir(cfg.PROC / f"{sensor}_rgb.tif", comp.a_uint8(rgb), perfil,
                    ["R", "G", "B"], dtype="uint8", nodata=0)
        r_co, r_cx = rad.resumen(co, g[co]), rad.resumen(cx, g[cx])
        # cociente de MEDIAS (la media de cocientes con speckle está sesgada al alza)
        r_ra = {"capa": f"{co}/{cx}", "media_db": round(r_co["media_db"] - r_cx["media_db"], 2),
                "std_db": round(float(np.nanstd(co_db - cx_db)), 2), "unidad": "dB",
                "n_validos": int(np.isfinite(ratio_lin).sum())}
        stats[sensor] = [r_co, r_cx, r_ra]
        capas[sensor] = f"{sensor}_gamma0_db.tif"

    io.escribir(cfg.PROC / "s2_refl.tif", np.stack([refl["B8"], refl["B3"], refl["B4"]]),
                perfil, ["NIR_B8", "Green_B3", "Red_B4"])
    io.escribir(cfg.PROC / "s2_rgb.tif",
                comp.a_uint8(comp.rgb_optico(refl["B4"], refl["B3"], refl["B2"], 1.2)),
                perfil, ["R_B4", "G_B3", "B_B2"], dtype="uint8", nodata=0)
    ndvi = (refl["B8"] - refl["B4"]) / (refl["B8"] + refl["B4"])
    io.escribir(cfg.PROC / "s2_ndvi.tif", ndvi, perfil, ["NDVI"])
    stats["s2"] = [rad.resumen(n, refl=refl[b]) for n, b in
                   (("NIR", "B8"), ("Green", "B3"), ("Red", "B4"))] + [rad.resumen("NDVI", refl=ndvi)]

    extra = {"s1": meta_s1, "alos": meta_al,
             "grilla": {"crs": str(perfil["crs"]), "ancho": perfil["width"],
                        "alto": perfil["height"], "pixel_m": abs(perfil["transform"][0])}}
    if "slc" in man:
        extra["slc"] = procesar_slc(man["slc"])
    actualizar_manifiesto(procesamiento={"estadisticas": stats, "extra": extra,
                                         "dir": str(cfg.PROC)})
    L.info("Módulo 2 terminado")

def procesar_slc(slc):
    s_vv, s_vh = pol.leer_complejo_snap(slc["dir_complejo"])
    c11, c22, c12 = pol.matriz_c2(s_vv, s_vh, cfg.SLC["ventana_c2"])
    H, alfa, _ = pol.h_alpha(c11, c22, c12)
    rho = pol.coherencia(c11, c22, c12)
    np.savez_compressed(cfg.PROC / "slc_polarimetria.npz",
                        amp_vv=pol.amplitud(s_vv), fase_vv=pol.fase(s_vv),
                        fase_vh=pol.fase(s_vh), dphi=pol.diferencia_fase(c12),
                        rho=rho, H=H, alfa=alfa)
    return {"H_media": float(np.nanmean(H)), "alfa_media_deg": float(np.nanmean(alfa)),
            "coherencia_media": float(np.nanmean(rho)), "geometria": "slant-range"}
