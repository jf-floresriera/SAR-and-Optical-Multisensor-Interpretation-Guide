"""Conversiones radiométricas (guía CEOS, secciones 2.3 y 3.1.2.3).
REGLA DE ORO: promediar SIEMPRE en potencia lineal y convertir a dB al final."""
import numpy as np
import config as cfg

def alos_dn_a_lineal(dn, k_db=cfg.K_ALOS_DB):
    """gamma0 = DN² · 10^(K/10)   (equivale a 10·log10(DN²) + K en dB)."""
    dn = np.asarray(dn, dtype="float64")
    out = dn ** 2 * 10 ** (k_db / 10)
    out[~(dn > 0)] = np.nan
    return out

def sigma_a_gamma(sigma0, theta_deg):
    """gamma0 = sigma0 / cos(theta). Con el ángulo ELIPSOIDAL de GEE esto normaliza
    near/far-range, pero no es una RTC completa (no usa pendiente local)."""
    return sigma0 / np.cos(np.deg2rad(theta_deg))

def a_db(lin):
    lin = np.where(lin > 0, lin, np.nan)
    return 10 * np.log10(lin)

def media_db(lin):
    return float(10 * np.log10(np.nanmean(lin)))

def std_db(lin):
    return float(np.nanstd(a_db(lin)))

def s2_reflectancia(dn):
    """Colección armonizada: rho = DN/10000 (offset de baseline 04.00 ya compensado)."""
    r = np.asarray(dn, dtype="float64") / 10000.0
    r[dn == 0] = np.nan
    return r

def resumen(nombre, lin=None, refl=None):
    if lin is not None:
        return {"capa": nombre, "media_db": round(media_db(lin), 2),
                "std_db": round(std_db(lin), 2), "unidad": "dB",
                "n_validos": int(np.isfinite(lin).sum())}
    return {"capa": nombre, "media": round(float(np.nanmean(refl)), 4),
            "std": round(float(np.nanstd(refl)), 4), "unidad": "reflectancia",
            "n_validos": int(np.isfinite(refl).sum())}
