"""Filtros de speckle. El speckle es ruido MULTIPLICATIVO: I = R·n, con E[n]=1 y
Var[n]=1/ENL (ENL = número equivalente de looks). Filtrar en lineal, nunca en dB."""
import numpy as np
from scipy.ndimage import uniform_filter

def lee(img, ventana=5, enl=4.4):
    """Filtro de Lee (1980): R̂ = m + k·(I − m),  k = max(0, 1 − Cu²/Ci²)
    Cu² = 1/ENL (variación del ruido), Ci² = var_local/m² (variación observada)."""
    mascara = ~np.isfinite(img)
    x = np.where(mascara, np.nanmedian(img), img)
    m = uniform_filter(x, ventana)
    var = np.maximum(uniform_filter(x * x, ventana) - m * m, 0)
    ci2 = var / np.maximum(m * m, 1e-12)
    k = np.clip(1 - (1.0 / enl) / np.maximum(ci2, 1e-12), 0, 1)
    out = m + k * (x - m)
    out[mascara] = np.nan
    return out

def enl_estimado(img, ventana=9):
    """ENL ≈ media²/varianza en zonas homogéneas (se usa la mediana local)."""
    x = np.nan_to_num(img)
    m = uniform_filter(x, ventana)
    v = uniform_filter(x * x, ventana) - m * m
    r = (m * m / np.maximum(v, 1e-12))[m > 0]
    return float(np.nanmedian(r))

FILTROS = {"lee": lee}   # punto de extensión: añadir "refined_lee", "gamma_map", …
