"""MÓDULO 3 – Productos finales: panel PNG, PNG individuales, PDF (los GeoTIFF vienen del módulo 2)."""
import config as cfg
from nucleo.utilidades import log, leer_manifiesto, actualizar_manifiesto
from . import panel, reporte_pdf

L = log("M3")

def ejecutar():
    man = leer_manifiesto()
    cfg.PROD.mkdir(parents=True, exist_ok=True)
    png = panel.generar(man, cfg.PROD / "panel_guia.png")
    fase = None
    npz = cfg.PROC / "slc_polarimetria.npz"
    if npz.exists():
        fase = panel.panel_fase(npz, cfg.PROD / "panel_fase.png")
    pdf = reporte_pdf.construir(man, png, cfg.PROD / "guia_interpretacion.pdf", fase)
    actualizar_manifiesto(productos={"panel_png": str(png), "pdf": str(pdf),
                                     "geotiff": sorted(str(p) for p in cfg.PROC.glob("*.tif"))})
    L.info(f"Productos en {cfg.PROD}")
