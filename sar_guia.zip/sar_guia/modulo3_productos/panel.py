"""Panel tipo guía CEOS: 3 filas (S1, ALOS-2, S2) x 4 columnas (canal1, canal2, cociente/banda3, RGB)."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import config as cfg
from nucleo import io_raster as io
from modulo2_procesamiento.composiciones import estirar

FILAS = [  # (sensor, archivo, etiquetas, prefijo, rgb, etiqueta RGB)
    ("s1", "s1_gamma0_db.tif", ["VV", "VH", "VV/VH"], "C-", "s1_rgb.tif", "R: C-VV\nG: C-VH\nB: C-VV/C-VH"),
    ("alos", "alos_gamma0_db.tif", ["HH", "HV", "HH/HV"], "L-", "alos_rgb.tif", "R: L-HH\nG: L-HV\nB: L-HH/L-HV"),
    ("s2", "s2_refl.tif", ["NIR", "Green", "Red"], "S2-", "s2_rgb.tif", "R: B4\nG: B3\nB: B2"),
]
_contorno = [pe.withStroke(linewidth=2.5, foreground="black")]

def _rotulo(ax, txt, esquina="sup"):
    y, va = (0.97, "top") if esquina == "sup" else (0.03, "bottom")
    ax.text(0.03, y, txt, transform=ax.transAxes, color="white", fontsize=10,
            va=va, ha="left", path_effects=_contorno, family="DejaVu Sans")

def _barra_escala(ax, pixel_m, ancho_px, km=1):
    n = km * 1000 / pixel_m
    x0 = ancho_px * 0.95 - n
    y = ax.get_ylim()[0] * 0.95
    ax.plot([x0, x0 + n], [y, y], color="white", lw=3, path_effects=_contorno)
    ax.text(x0 + n / 2, y * 0.97, f"{km} km", color="white", ha="center", va="bottom",
            fontsize=9, path_effects=_contorno)

def _leyenda(stat, sensor, prefijo):
    if sensor == "s2":
        return f"{prefijo}{stat['capa']}: {stat['media']:.3f} (±{stat['std']:.3f})"
    return f"{prefijo}{stat['capa']}: {stat['media_db']:.1f} (±{stat['std_db']:.1f}) dB"

def generar(man, salida_png, guardar_individuales=True):
    stats = man["procesamiento"]["estadisticas"]
    adq = man["adquisicion"]
    pix = man["procesamiento"]["extra"]["grilla"]["pixel_m"]
    fig, axes = plt.subplots(3, 4, figsize=(17, 14.5), constrained_layout=True)
    indiv = cfg.PROD / "paneles_individuales"
    indiv.mkdir(parents=True, exist_ok=True)
    for f, (sensor, arch, etiq, pref, arch_rgb, txt_rgb) in enumerate(FILAS):
        arr, _, _ = io.leer(cfg.PROC / arch)
        rgb = io.leer(cfg.PROC / arch_rgb)[0].transpose(1, 2, 0) / 255.0
        for c in range(3):
            ax = axes[f, c]
            img = estirar(arr[c])
            ax.imshow(img, cmap="gray", interpolation="nearest")
            _rotulo(ax, f"{pref}{etiq[c]}")
            ax.set_xlabel(_leyenda(stats[sensor][c], sensor, pref), fontsize=11)
            if guardar_individuales:
                plt.imsave(indiv / f"{sensor}_{etiq[c].replace('/', '_')}.png", img, cmap="gray")
        ax = axes[f, 3]
        ax.imshow(rgb, interpolation="nearest")
        _rotulo(ax, txt_rgb)
        _barra_escala(ax, pix, rgb.shape[1])
        ax.set_xlabel(f"Fecha de observación: {adq[sensor]['fecha']}", fontsize=11)
        if guardar_individuales:
            plt.imsave(indiv / f"{sensor}_RGB.png", rgb)
        for a in axes[f]:
            a.set_xticks([]); a.set_yticks([])
    fig.suptitle(f"{cfg.NOMBRE_AOI} — Sentinel-1 (C), ALOS-2 PALSAR-2 (L), Sentinel-2 (óptico)\n"
                 f"Separación temporal máxima: {adq['span_dias']} días", fontsize=14, weight="bold")
    fig.savefig(salida_png, dpi=300)
    plt.close(fig)
    return salida_png

def panel_fase(npz, salida_png):
    d = np.load(npz)
    cfgs = [("amp_vv", "Amplitud |s_VV|", "gray", True), ("fase_vv", "Fase φ_VV (rad)", "twilight", False),
            ("dphi", "Δφ VV−VH (rad)", "twilight", False), ("rho", "Coherencia |ρ12|", "viridis", False),
            ("H", "Entropía H", "magma", False), ("alfa", "α medio (°)", "jet", False)]
    fig, axes = plt.subplots(2, 3, figsize=(15, 9), constrained_layout=True)
    for ax, (k, t, cm, est) in zip(axes.flat, cfgs):
        v = d[k]
        im = ax.imshow(estirar(20 * np.log10(v + 1e-9)) if est else v, cmap=cm)
        ax.set_title(t); ax.set_xticks([]); ax.set_yticks([])
        if not est:
            fig.colorbar(im, ax=ax, shrink=0.8)
    fig.suptitle("Sentinel-1 SLC — información de fase y polarimetría dual (geometría slant-range)")
    fig.savefig(salida_png, dpi=200)
    plt.close(fig)
    return salida_png
