"""Reporte PDF científico (ReportLab). Fuente DejaVu (incluida con matplotlib) para σ, γ, λ, φ."""
from pathlib import Path
import matplotlib
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                Image, PageBreak)
import config as cfg
from . import textos as tx

_f = Path(matplotlib.get_data_path()) / "fonts" / "ttf"
pdfmetrics.registerFont(TTFont("DV", str(_f / "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("DV-B", str(_f / "DejaVuSans-Bold.ttf")))
pdfmetrics.registerFont(TTFont("DV-I", str(_f / "DejaVuSans-Oblique.ttf")))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("DV", normal="DV", bold="DV-B", italic="DV-I", boldItalic="DV-B")

AZUL = colors.HexColor("#1F4E79")
st = getSampleStyleSheet()
N = ParagraphStyle("n", parent=st["Normal"], fontName="DV", fontSize=9.5, leading=13.5, alignment=4)
H1 = ParagraphStyle("h1", parent=N, fontName="DV-B", fontSize=15, textColor=AZUL, spaceBefore=10, spaceAfter=6, alignment=0)
H2 = ParagraphStyle("h2", parent=H1, fontSize=11.5, spaceBefore=8, spaceAfter=3)
T = ParagraphStyle("t", parent=N, fontSize=7.5, leading=9.5, alignment=0)
TIT = ParagraphStyle("tit", parent=H1, fontSize=22, alignment=1, leading=28)

def _tabla(filas, anchos, cabecera=True):
    data = [[Paragraph(str(c), T) for c in f] for f in filas]
    t = Table(data, colWidths=anchos, repeatRows=1 if cabecera else 0)
    estilo = [("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP")]
    if cabecera:
        estilo += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DCE6F1"))]
    t.setStyle(TableStyle(estilo))
    return t

CLAVES = {
    "s1": ["id", "platform_number", "instrumentMode", "orbitProperties_pass", "relativeOrbitNumber_start",
           "resolution_meters", "transmitterReceiverPolarisation", "sliceNumber", "productTimelinessCategory"],
    "s2": ["id", "SPACECRAFT_NAME", "MGRS_TILE", "PROCESSING_BASELINE", "SENSING_ORBIT_NUMBER",
           "SENSING_ORBIT_DIRECTION", "MEAN_SOLAR_ZENITH_ANGLE", "MEAN_SOLAR_AZIMUTH_ANGLE",
           "CLOUDY_PIXEL_PERCENTAGE"],
}

def _metadatos_sensor(sensor, adq):
    md = adq[sensor].get("metadatos", [])
    filas = [["Propiedad", "Valor"]]
    for m in md:
        claves = CLAVES.get(sensor) or list(m)[:14]
        filas += [[k, m[k]] for k in claves if k in m]
    return filas

def construir(man, panel_png, salida_pdf, panel_fase_png=None):
    adq, pr = man["adquisicion"], man["procesamiento"]
    stats, extra = pr["estadisticas"], pr["extra"]
    doc = SimpleDocTemplate(str(salida_pdf), pagesize=A4, leftMargin=1.8*cm, rightMargin=1.8*cm,
                            topMargin=1.6*cm, bottomMargin=1.6*cm,
                            title="Guía de interpretación SAR/óptico", author="sar_guia")
    s = []
    s += [Spacer(1, 5*cm), Paragraph("Guía de interpretación multisensor", TIT),
          Paragraph("Sentinel-1 (banda C) · ALOS-2 PALSAR-2 (banda L) · Sentinel-2 (óptico)", H2),
          Spacer(1, 1*cm), Paragraph(cfg.NOMBRE_AOI, H2),
          Paragraph(f"Fechas: S1 {adq['s1']['fecha']} · ALOS-2 {adq['alos']['fecha']} · "
                    f"S2 {adq['s2']['fecha']} (separación máx. {adq['span_dias']} días)", N),
          Paragraph("Metodología basada en Rosenqvist et al. (2023), CEOS Layman's SAR Interpretation Guide v3.0.", N),
          PageBreak()]

    # 1. Área y geometría
    a = man["aoi"]; g = extra["grilla"]
    lon = [p[0] for p in a["lonlat"]]; lat = [p[1] for p in a["lonlat"]]
    s += [Paragraph("1. Área de interés y grilla de trabajo", H1),
          _tabla([["Parámetro", "Valor"],
                  ["CRS de origen / bbox", f"{a['crs_origen']} · {tuple(round(v, 2) for v in a['bbox'])}"],
                  ["Extensión geográfica (WGS84)", f"lon {min(lon):.4f}° a {max(lon):.4f}° · lat {min(lat):.4f}° a {max(lat):.4f}°"],
                  ["CRS de trabajo", g["crs"]],
                  ["Grilla común", f"{g['ancho']} × {g['alto']} píxeles · {g['pixel_m']:.1f} m"],
                  ["Remuestreo", "S1: bilineal en potencia · ALOS-2 25→10 m bilineal en potencia · S2 referencia"]],
                 [5*cm, 12*cm])]

    # 2. Fundamentos
    s += [Paragraph("2. Fundamentos físicos y matemáticos", H1)]
    for t, p in tx.FUNDAMENTOS:
        s += [Paragraph(t, H2), Paragraph(p, N)]
    fis = [["Sensor", "Banda", "Frecuencia", "λ", "Polarización / bandas", "Agencia"]]
    for k in ("s1", "alos"):
        d = cfg.SENSORES[k]
        fis.append([d["nombre"], d["banda"], f"{d['f_hz']/1e9:.4f} GHz", f"{tx.lambda_cm(d['f_hz']):.2f} cm",
                    " + ".join(d["pols"]), d["agencia"]])
    d = cfg.SENSORES["s2"]
    fis.append([d["nombre"], d["banda"], "—", " / ".join(f"{v:.0f} nm" for v in d["bandas_nm"].values()),
                "B2, B3, B4, B8", d["agencia"]])
    s += [Spacer(1, 6), _tabla(fis, [3.3*cm, 1.4*cm, 2.2*cm, 3.2*cm, 3.4*cm, 3*cm]),
          Paragraph("Nota: λ se calcula como c/f; la guía CEOS redondea banda L a ~23.5 cm "
                    "(valor de PALSAR-1); PALSAR-2 opera a 1.2365 GHz (≈24.2 cm).", T)]

    # 3. Metadatos
    s += [Paragraph("3. Datos y metadatos de las escenas", H1)]
    for k, nom in (("s1", "Sentinel-1"), ("alos", "ALOS-2 PALSAR-2"), ("s2", "Sentinel-2")):
        s += [Paragraph(f"{nom} — {adq[k]['producto']}", H2),
              Paragraph(f"Fecha: {adq[k]['fecha']} · escenas: {len(adq[k]['ids'])} · bandas descargadas: "
                        f"{', '.join(adq[k]['bandas'])}", N),
              _tabla(_metadatos_sensor(k, adq), [5.5*cm, 11.5*cm])]
    s += [Paragraph("Parámetros derivados", H2),
          _tabla([["Parámetro", "Valor"],
                  ["S1 ángulo de incidencia (elipsoidal) media / rango",
                   f"{extra['s1']['angulo_inc_media']:.2f}° ({extra['s1']['angulo_inc_min']:.2f}°–{extra['s1']['angulo_inc_max']:.2f}°)"],
                  ["S1 ENL estimado (σ0 sin filtrar)", f"{extra['s1']['enl_estimado_VV_crudo']:.2f}"],
                  ["ALOS-2 ángulo de incidencia local medio", f"{extra['alos']['angulo_inc_local_media']:.2f}°"],
                  ["ALOS-2 máscara (valor: nº píxeles)", extra["alos"]["mascara_valores"]],
                  ["S2 nubes en AOI (SCL)", f"{adq['s2'].get('nubes_aoi_pct', '—')} %"]],
                 [7*cm, 10*cm]),
          PageBreak()]

    # 4. Panel
    s += [Paragraph("4. Panel de interpretación", H1),
          Image(str(panel_png), width=17*cm, height=17*cm * 14.5 / 17),
          Paragraph("Valores bajo cada imagen: media (calculada en potencia lineal) y desviación estándar "
                    "(en dB) del AOI. Imágenes en escala de grises estiradas al percentil 2–98 de cada canal "
                    "(la escala visual NO es comparable entre canales). RGB SAR: R=co-pol, G=cross-pol, "
                    "B=co/cross. RGB óptico: color verdadero.", T),
          PageBreak()]

    # 5. Interpretación
    v, cerc = tx.clases_cercanas(stats)
    s += [Paragraph("5. Interpretación", H1),
          Paragraph(f"Valores medios del AOI: L-HH {v[0]:.1f} dB, L-HV {v[1]:.1f} dB, "
                    f"C-VV {v[2]:.1f} dB, C-VH {v[3]:.1f} dB, NDVI {stats['s2'][3]['media']:.2f}.", N),
          Paragraph("Clases de la guía CEOS más cercanas (distancia euclidiana en el espacio "
                    "[L-HH, L-HV, C-VV, C-VH]) — orientativo:", N),
          _tabla([["Clase de referencia", "L-HH", "L-HV", "C-VV", "C-VH", "Distancia (dB)"]] +
                 [[k] + list(tx.REFERENCIA_CEOS[k]) + [f"{dd:.1f}"] for k, dd in cerc],
                 [6*cm, 1.8*cm, 1.8*cm, 1.8*cm, 1.8*cm, 2.8*cm]),
          Paragraph("Claves de lectura", H2),
          Paragraph("• L-HV alto (> −15 dB) → dispersión de volumen en ramas/troncos: bosque o plantación madura. "
                    "L-HV muy bajo (< −20 dB) → pastos, cultivos de secano, suelo o agua.<br/>"
                    "• L-HH muy alto con L-HV moderado → doble rebote: bosque inundado o arroz en crecimiento.<br/>"
                    "• C-VH responde a vegetación baja y cultivos (volumen en banda C); C-VV bajo con C-VH bajo "
                    "→ suelo liso o agua (tonos azules en el RGB).<br/>"
                    "• NIR alto con rojo bajo (NDVI > 0.6) confirma vegetación densa; úsese para validar la lectura SAR.", N),
          Paragraph("6. Precauciones", H1), Paragraph(tx.PRECAUCIONES, N)]

    if panel_fase_png and "slc" in extra:
        e = extra["slc"]
        s += [PageBreak(), Paragraph("7. Fase y polarimetría (Sentinel-1 SLC)", H1),
              Paragraph(f"H media = {e['H_media']:.2f}; α media = {e['alfa_media_deg']:.1f}°; "
                        f"coherencia VV-VH media = {e['coherencia_media']:.2f}.", N),
              Image(str(panel_fase_png), width=17*cm, height=10.2*cm)]
    else:
        s += [Paragraph("7. Fase", H1),
              Paragraph("Esta edición usa productos detectados (sin fase). Active SLC['activar'] en "
                        "config.py para añadir fase, coherencia interpolar y H/α a partir de Sentinel-1 SLC.", N)]

    s += [Paragraph("Referencias", H1)] + [Paragraph(r, T) for r in tx.REFERENCIAS]
    doc.build(s, onFirstPage=_pie, onLaterPages=_pie)
    return salida_pdf

def _pie(c, doc):
    c.saveState(); c.setFont("DV", 7.5); c.setFillColor(colors.grey)
    c.drawString(1.8*cm, 1*cm, "Guía de interpretación multisensor · generado con sar_guia")
    c.drawRightString(A4[0] - 1.8*cm, 1*cm, f"{doc.page}")
    c.restoreState()
