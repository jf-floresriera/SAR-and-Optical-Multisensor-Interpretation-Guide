"""Contenido científico del reporte y valores de referencia de la guía CEOS v3.0
(Rosenqvist et al., 2023). Los valores son de UNA escena por clase: solo orientativos."""
import config as cfg

REFERENCIA_CEOS = {  # clase: (L-HH, L-HV, C-VV, C-VH) en dB
    "Bosque tropical denso (Colombia)": (-9.4, -13.9, -8.1, -14.6),
    "Deforestación / sucesión secundaria (Colombia)": (-10.9, -18.5, -8.4, -13.1),
    "Bosque inundable (Brasil)": (-2.9, -12.7, -6.5, -12.3),
    "Manglar (Bangladesh)": (-8.7, -15.9, -8.7, -14.9),
    "Plantación de caucho (Vietnam)": (-4.8, -10.6, -6.5, -12.8),
    "Palma de aceite (Indonesia)": (-7.2, -14.6, -5.7, -13.3),
    "Acacia (Indonesia)": (-7.2, -12.3, -9.0, -13.0),
    "Arroz irrigado (Vietnam)": (-12.5, -22.6, -10.3, -16.3),
    "Agricultura de secano (Suiza)": (-11.7, -20.5, -11.3, -17.8),
    "Pastos / potreros (Brasil)": (-14.0, -24.4, -12.0, -19.4),
    "Sabana (Tanzania/Kenia)": (-15.8, -24.9, -10.6, -17.5),
    "Terreno árido rocoso (Kenia)": (-6.9, -15.1, -8.3, -18.4),
    "Agua abierta (Chagos)": (-27.6, -38.9, -16.6, -35.1),
}

def clases_cercanas(stats, n=3):
    v = (stats["alos"][0]["media_db"], stats["alos"][1]["media_db"],
         stats["s1"][0]["media_db"], stats["s1"][1]["media_db"])
    d = {k: sum((a - b) ** 2 for a, b in zip(v, r)) ** 0.5 for k, r in REFERENCIA_CEOS.items()}
    return v, sorted(d.items(), key=lambda x: x[1])[:n]

def lambda_cm(f_hz):
    return 100 * cfg.C / f_hz

FUNDAMENTOS = [
("Naturaleza de la señal",
 "El SAR es un sensor activo de microondas: emite pulsos coherentes y registra el eco "
 "retrodispersado. Cada píxel de un producto SLC es un número complejo "
 "<i>s = I + jQ = A·e<super>jφ</super></i>, donde la amplitud <i>A = |s|</i> depende de la "
 "rugosidad, geometría y constante dieléctrica del terreno, y la fase <i>φ = atan2(Q, I)</i> "
 "codifica la distancia sensor-blanco (módulo λ/2) más una fase de dispersión aleatoria. "
 "Los productos GRD y los mosaicos ALOS son <b>detectados</b> (|s|² promediado): la fase se "
 "descarta de forma irreversible. Por ello, el análisis de fase de este flujo usa SLC (módulo 1c)."),
("Longitud de onda y penetración",
 "λ = c / f. Los objetos mucho menores que λ son casi transparentes. Banda L (λ≈24 cm) atraviesa "
 "el dosel e interactúa con ramas y troncos (sensibilidad a biomasa hasta ~100 t/ha); banda C "
 "(λ≈5.5 cm) interactúa con hojas y ramas finas, siendo más sensible a vegetación baja, cultivos y "
 "rugosidad superficial. El sensor óptico (0.49–0.83 µm) mide reflectancia solar de la superficie "
 "y no penetra nubes."),
("Coeficientes de retrodispersión",
 "σ<super>0</super> = 10·log<sub>10</sub>(⟨DN²⟩) + K  (amplitud);  σ<super>0</super> = 10·log<sub>10</sub>(⟨DN⟩) + K (potencia). "
 "γ<super>0</super> = σ<super>0</super> / cos θ, con θ el ángulo de incidencia. Para ALOS-2 (JAXA): "
 "γ<super>0</super> = 10·log<sub>10</sub>(⟨DN²⟩) − 83.0 dB. El promedio ⟨·⟩ se calcula SIEMPRE en "
 "potencia lineal; la desviación estándar reportada se calcula en dB, como en la guía CEOS."),
("Speckle",
 "El speckle es un ruido multiplicativo: I = R·n con E[n]=1, Var[n]=1/ENL. La intensidad de un look "
 "sigue una distribución exponencial y la amplitud una Rayleigh; la fase de un píxel aislado es "
 "uniforme en (−π, π]. Se aplica un filtro de Lee (k = 1 − C<sub>u</sub>²/C<sub>i</sub>²) sobre potencia lineal "
 "con ENL = 4.4 (Sentinel-1 IW GRDH)."),
("Polarimetría dual y fase",
 "Con los canales complejos VV y VH se construye la matriz de covarianza "
 "C2 = ⟨k·k<super>H</super>⟩, k = [s<sub>VV</sub>, s<sub>VH</sub>]<super>T</super>. De ella se derivan la coherencia interpolar "
 "ρ = |C12|/√(C11·C22), la diferencia de fase Δφ = arg(C12) y la descomposición H/α dual "
 "(autovalores λ1 ≥ λ2; H = −Σp<sub>i</sub>log<sub>2</sub>p<sub>i</sub>; α = Σp<sub>i</sub>·arccos|e<sub>i1</sub>|). "
 "H bajo con α bajo indica dispersión superficial; H alto indica dispersión de volumen (vegetación)."),
("Mecanismos de dispersión",
 "Directa (co-pol alta: rocas, pendientes hacia el radar, hojas en banda C); especular hacia adelante "
 "(agua calma, suelo liso: oscuro en ambas polarizaciones); difusa (superficies rugosas); doble rebote "
 "(troncos o tallos sobre agua o suelo: co-pol muy alta, típico de bosque inundado y arroz); volumen "
 "(copas: aumenta la polarización cruzada). La señal total es la suma de contribuciones."),
("Óptico (Sentinel-2)",
 "Reflectancia de superficie ρ = π·L·d² / (E<sub>sun</sub>·cos θ<sub>s</sub>) corregida atmosféricamente (Sen2Cor, L2A). "
 "Bandas: B2 azul 492 nm, B3 verde 560 nm, B4 rojo 665 nm (10 m), B8 NIR 833 nm (10 m). "
 "NDVI = (NIR − Rojo)/(NIR + Rojo). Máscara de nubes: clases SCL 3, 8, 9, 10."),
]

PRECAUCIONES = (
 "Los valores son de una sola fecha y dependen de humedad, fenología, viento y lluvia. "
 "Banda C se atenúa con lluvia intensa; banda L puede aumentar HH con dosel mojado. "
 "El γ<super>0</super> de Sentinel-1 en este flujo usa el ángulo elipsoidal (no es RTC completa): en relieve "
 "abrupto use productos RTC (p.ej. ASF HyP3). Las coordenadas geográficas no son de área igual; el "
 "cálculo se hace en UTM 18N. La comparación con la guía CEOS es orientativa, no una clasificación.")

REFERENCIAS = [
 "Rosenqvist A., Killough B., Dyke G., Borges D. (2023). A Layman's Interpretation Guide to L-band and C-band SAR data, v3.0. CEOS.",
 "Shimada M. (2010). Ortho-rectification and slope correction of SAR data using DEM. IEEE JSTARS 3(4):657–671.",
 "Lee J.-S. (1980). Digital image enhancement and noise filtering by use of local statistics. IEEE TPAMI 2(2).",
 "Cloude S. R. (2007). The dual polarization entropy/alpha decomposition. Proc. PolInSAR, ESA.",
 "ESA Sentinel-1 y Sentinel-2 User Guides; JAXA PALSAR-2 ScanSAR/Mosaic Dataset Description.",
 "Gorelick N. et al. (2017). Google Earth Engine. Remote Sensing of Environment 202:18–27.",
]
