"""Única puerta de entrada/salida raster (rasterio). Si mañana cambias a xarray
o COG en la nube, solo cambias este archivo."""
import numpy as np

def leer(ruta):
    """Devuelve (array [bandas, filas, cols] float64, perfil, descripciones)."""
    import rasterio
    with rasterio.open(ruta) as ds:
        return ds.read().astype("float64"), ds.profile.copy(), list(ds.descriptions)

def alinear(ruta, perfil_ref, remuestreo="bilinear", cero_es_nodata=True):
    """Reproyecta/remuestrea un raster a la grilla de referencia (S2 10 m)."""
    import rasterio
    from rasterio.warp import reproject, Resampling
    with rasterio.open(ruta) as ds:
        dst = np.full((ds.count, perfil_ref["height"], perfil_ref["width"]), np.nan)
        for b in range(ds.count):
            src = ds.read(b + 1).astype("float64")
            if cero_es_nodata:
                src[src == 0] = np.nan
            reproject(src, dst[b], src_transform=ds.transform, src_crs=ds.crs,
                      dst_transform=perfil_ref["transform"], dst_crs=perfil_ref["crs"],
                      src_nodata=np.nan, dst_nodata=np.nan,
                      resampling=getattr(Resampling, remuestreo))
    return dst

def escribir(ruta, arr, perfil_ref, descripciones, dtype="float32", nodata=np.nan):
    import rasterio
    if arr.ndim == 2:
        arr = arr[None]
    p = perfil_ref.copy()
    p.update(driver="GTiff", count=arr.shape[0], dtype=dtype, nodata=nodata,
             compress="deflate", tiled=True, blockxsize=256, blockysize=256)
    with rasterio.open(ruta, "w", **p) as ds:
        ds.write(arr.astype(dtype))   # uint8: el llamador ya reemplazó NaN
        for i, d in enumerate(descripciones, 1):
            ds.set_band_description(i, d)

def reproyectar(arr, perfil_src, perfil_ref, remuestreo="bilinear"):
    """Como alinear(), pero sobre un array ya en memoria (p.ej. potencia lineal)."""
    from rasterio.warp import reproject, Resampling
    arr = arr[None] if arr.ndim == 2 else arr
    dst = np.full((arr.shape[0], perfil_ref["height"], perfil_ref["width"]), np.nan)
    for b in range(arr.shape[0]):
        reproject(arr[b], dst[b], src_transform=perfil_src["transform"], src_crs=perfil_src["crs"],
                  dst_transform=perfil_ref["transform"], dst_crs=perfil_ref["crs"],
                  src_nodata=np.nan, dst_nodata=np.nan,
                  resampling=getattr(Resampling, remuestreo))
    return dst
