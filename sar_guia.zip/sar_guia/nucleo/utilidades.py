"""Utilidades compartidas: AOI, manifiesto JSON (contrato entre módulos) y logging."""
import json, logging
from datetime import datetime, timezone
import config as cfg

def log(nombre):
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")
    return logging.getLogger(nombre)

def aoi_lonlat():
    """Transforma el bbox EPSG:3857 a un anillo lon/lat (EPSG:4326)."""
    from pyproj import Transformer
    t = Transformer.from_crs(cfg.AOI_CRS, "EPSG:4326", always_xy=True)
    x0, y0, x1, y1 = cfg.AOI_BBOX
    lon, lat = t.transform([x0, x1, x1, x0, x0], [y0, y0, y1, y1, y0])
    return [list(p) for p in zip(lon, lat)]

def leer_manifiesto():
    return json.loads(cfg.MANIFIESTO.read_text()) if cfg.MANIFIESTO.exists() else {}

def actualizar_manifiesto(**secciones):
    """Cada módulo SOLO escribe sus propias claves -> no pisa a los demás."""
    m = leer_manifiesto()
    m.update(secciones)
    m["actualizado"] = datetime.now(timezone.utc).isoformat()
    cfg.MANIFIESTO.parent.mkdir(parents=True, exist_ok=True)
    cfg.MANIFIESTO.write_text(json.dumps(m, indent=2, ensure_ascii=False, default=str))
    return m
