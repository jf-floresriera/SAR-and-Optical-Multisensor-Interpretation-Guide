"""Prueba SIN internet ni rasterio: escena sintética -> módulos 2 y 3.
Sustituye nucleo.io_raster por un almacén en memoria (demuestra el desacople).
Uso:  python -m pruebas.prueba_offline"""
import numpy as np
from scipy.ndimage import zoom
import config as cfg
from nucleo import io_raster, utilidades as ut
from modulo2_procesamiento import polarimetria as pol

RNG = np.random.default_rng(0)
ALMACEN = {}
N = 514

def _perfil(px, n):
    return {"width": n, "height": n, "transform": (px, 0, 0, 0, -px, 0), "crs": "EPSG:32618"}

io_raster.leer = lambda r: (ALMACEN[str(r)][0].astype("float64"), ALMACEN[str(r)][1], ALMACEN[str(r)][2])
io_raster.escribir = lambda r, a, p, d, dtype="float32", nodata=None: ALMACEN.__setitem__(
    str(r), ((a[None] if a.ndim == 2 else a).astype(dtype), p, d))
def _alinear(r, pref, rem="bilinear", cero_es_nodata=True):
    a, p, _ = ALMACEN[str(r)]
    return io_raster.reproyectar(a.astype(float), p, pref, rem)
def _reproy(a, ps, pr, rem="bilinear"):
    a = a[None] if a.ndim == 2 else a
    f = pr["height"] / a.shape[1]
    return np.stack([zoom(np.nan_to_num(b), f, order=1 if rem == "bilinear" else 0) for b in a])
io_raster.alinear, io_raster.reproyectar = _alinear, _reproy

def escena():
    """Clases: bosque (izq), pasto (centro), arroz (der-arriba), río (franja)."""
    y, x = np.mgrid[:N, :N]
    clase = np.where(x < 180, 0, np.where(x < 350, 1, np.where(y < 250, 2, 1)))
    clase[np.abs(y - 0.6 * x - 150) < 12] = 3
    # medias dB por clase (valores de la guía CEOS)
    tab = {"VV": [-8.1, -12.0, -10.3, -18], "VH": [-14.6, -19.4, -16.3, -30],
           "HH": [-9.4, -14.0, -12.5, -27], "HV": [-13.9, -24.4, -22.6, -38]}
    lin = {k: 10 ** (np.array(v)[clase] / 10) * RNG.exponential(1, (N, N)) for k, v in tab.items()}
    return clase, lin

def main():
    base = cfg.BASE.parent / "salidas_demo"
    cfg.BASE, cfg.RAW, cfg.PROC, cfg.PROD = base, base / "01_raw", base / "02_procesado", base / "03_productos"
    cfg.MANIFIESTO = base / "manifiesto.json"
    for d in (cfg.RAW, cfg.PROC, cfg.PROD):
        d.mkdir(parents=True, exist_ok=True)
    clase, lin = escena()
    ang = np.tile(np.linspace(33, 36, N), (N, 1))
    ALMACEN[str(cfg.RAW / "s1.tif")] = (np.stack([lin["VV"] * np.cos(np.deg2rad(ang)),
                                                   lin["VH"] * np.cos(np.deg2rad(ang)), ang]), _perfil(10, N), None)
    m25 = lambda a: zoom(a, 206 / N, order=1)
    dn = lambda g: np.sqrt(g / 10 ** (-8.3))
    ALMACEN[str(cfg.RAW / "alos.tif")] = (np.stack([m25(dn(lin["HH"])), m25(dn(lin["HV"])),
                                                     np.full((206, 206), 34.), np.full((206, 206), 7.)]),
                                          _perfil(25, 206), None)
    refl = {"B2": [300, 500, 450, 400], "B3": [600, 900, 800, 500], "B4": [300, 1200, 700, 300],
            "B8": [3500, 2500, 3000, 200]}
    s2 = [np.array(v)[clase] + RNG.normal(0, 60, (N, N)) for v in refl.values()]
    ALMACEN[str(cfg.RAW / "s2.tif")] = (np.stack(s2 + [np.full((N, N), 4.)]), _perfil(10, N), None)

    ut.actualizar_manifiesto(
        aoi={"crs_origen": cfg.AOI_CRS, "bbox": cfg.AOI_BBOX, "crs_trabajo": cfg.CRS_TRABAJO,
             "lonlat": [[-73.3366, 3.7693], [-73.2904, 3.7693], [-73.2904, 3.8153], [-73.3366, 3.8153]],
             "nombre": cfg.NOMBRE_AOI + " [DEMO SINTÉTICA]"},
        adquisicion={"span_dias": 6,
            "s1": {"fecha": "2021-04-02", "ids": ["demo"], "archivo": str(cfg.RAW / "s1.tif"),
                   "bandas": ["VV", "VH", "angle"], "producto": "SINTÉTICO", "metadatos": [{"id": "demo",
                   "platform_number": "A", "orbitProperties_pass": "ASCENDING", "relativeOrbitNumber_start": 150}]},
            "alos": {"fecha": "2021-04-05", "ids": ["demo"], "tipo": "scansar", "archivo": str(cfg.RAW / "alos.tif"),
                     "bandas": ["HH", "HV", "LIN", "MSK"], "producto": "SINTÉTICO", "metadatos": [{"id": "demo"}]},
            "s2": {"fecha": "2021-03-30", "ids": ["demo"], "archivo": str(cfg.RAW / "s2.tif"), "nubes_aoi_pct": 0,
                   "bandas": ["B2", "B3", "B4", "B8", "SCL"], "producto": "SINTÉTICO",
                   "metadatos": [{"id": "demo", "SPACECRAFT_NAME": "Sentinel-2A"}]}})

    # --- polarimetría sintética con correlación conocida (verifica la matemática de fase)
    rho_real = 0.6
    a = (RNG.normal(size=(300, 300)) + 1j * RNG.normal(size=(300, 300))) / np.sqrt(2)
    b = (RNG.normal(size=(300, 300)) + 1j * RNG.normal(size=(300, 300))) / np.sqrt(2)
    s_vv = a
    s_vh = 0.3 * (rho_real * a * np.exp(-1j * 0.8) + np.sqrt(1 - rho_real**2) * b)
    c11, c22, c12 = pol.matriz_c2(s_vv, s_vh, 15)
    rho = pol.coherencia(c11, c22, c12)
    H, alfa, _ = pol.h_alpha(c11, c22, c12)
    print(f"[polarimetría] ρ estimado={np.mean(rho):.3f} (real {rho_real}); "
          f"Δφ={np.mean(pol.diferencia_fase(c12)):.2f} rad (real 0.80); H={H.mean():.2f}; α={alfa.mean():.1f}°")
    np.savez_compressed(cfg.PROC / "slc_polarimetria.npz", amp_vv=np.abs(s_vv), fase_vv=np.angle(s_vv),
                        fase_vh=np.angle(s_vh), dphi=pol.diferencia_fase(c12), rho=rho, H=H, alfa=alfa)

    from modulo2_procesamiento import procesar
    procesar.ejecutar()
    m = ut.leer_manifiesto()
    m["procesamiento"]["extra"]["slc"] = {"H_media": float(H.mean()), "alfa_media_deg": float(alfa.mean()),
                                          "coherencia_media": float(rho.mean()), "geometria": "sintética"}
    ut.actualizar_manifiesto(procesamiento=m["procesamiento"])
    from modulo3_productos import generar
    generar.ejecutar()
    for s, v in m["procesamiento"]["estadisticas"].items():
        print(s, v)

if __name__ == "__main__":
    main()
